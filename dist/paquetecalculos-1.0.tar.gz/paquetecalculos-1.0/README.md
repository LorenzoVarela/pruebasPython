# pruebasPython
pruebas de python

Estamos siguiendo este curso
    https://www.youtube.com/watch?v=G2FCfQj-9ig&list=PLU8oAlHdN5BlvPxziopYZRd55pdqFwkeS