from setuptools import setup

setup(
    name = "paquetecalculos",
    version="1.0",
    description="Calculos matemáticos básicos",
    author="Lorenzo Varela",
    packages=["calculos","calculos.redondeo_potencia"]

)