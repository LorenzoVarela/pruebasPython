def sumar(op1, op2):
    print("La suma es: ", op1+op2)


def restar(op1, op2):
    print("La restar es: ", op1-op2)

def multiplicar(op1, op2):
    print("La multiplicación es: ", op1*op2)

def dividir(dividendo, divisor):
    print("La división es: ", dividendo/divisor)

def potencia(base, exponente):
    print("La potencia es: ", base**exponente)

def redondear(numero):
    print("Resultado es: ", round(numero))
