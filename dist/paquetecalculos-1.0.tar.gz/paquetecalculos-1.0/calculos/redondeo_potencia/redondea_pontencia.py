def potencia(base, exponente):
    print("La potencia es: ", base**exponente)

def redondear(numero):
    print("Resultado es: ", round(numero))
